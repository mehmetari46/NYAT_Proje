package pkt;

public interface ISicaklikAlgilayici {
    public int sicaklikOlc() ;

}
