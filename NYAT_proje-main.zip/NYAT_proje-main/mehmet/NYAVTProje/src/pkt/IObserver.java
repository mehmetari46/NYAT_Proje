package pkt;

public interface IObserver {
    public void update(int u);
}
