package pkt;

public interface IEyleyici {
    public void sogutucuAc();
    public void sogutucuKapat();
}
