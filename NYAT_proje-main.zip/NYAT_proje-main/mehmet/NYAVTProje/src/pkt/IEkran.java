package pkt;

public interface IEkran {
    public int menu();
}
