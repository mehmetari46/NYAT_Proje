package pkt;

public interface IBilgiSistemi {
    public boolean kullaniciDogrula(String kullaniciAdi , int sifre);
}
