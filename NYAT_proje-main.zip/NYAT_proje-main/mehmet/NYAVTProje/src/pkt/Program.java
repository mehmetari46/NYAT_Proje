package pkt;

public class Program {

    public static void main(String args[]){

        AkilliCihaz sogutucu=new AkilliCihaz.CihazBuilder("Xmarka").build();
        sogutucu.basla();

    }
}
